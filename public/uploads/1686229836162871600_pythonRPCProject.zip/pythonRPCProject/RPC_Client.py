import json
import struct
from threading import Thread
from socket import *


def Print(data):
    print(data)


class MyThread(Thread):
    def __init__(self, sock, args, callback=None):
        Thread.__init__(self)
        self.args=args
        self.sock=sock
        self.callback=callback  # 选择回调函数

    def run(self):
        result = RPCStub.AsynHandle(self=self.sock, d=self.args)
        if self.callback is not None:
            self.callback(result)
            self.sock.close()
        else:
            return result


class TCPClient(object):  # 封装TCP通信细节
    def __init__(self):
        pass

    def connect(self, serverName, serverPort):
        self.sock.connect((serverName, serverPort))

    def send(self, mes):
        self.sock.sendall(mes)

    def recv(self, leng):
        return self.sock.recv(leng)

    def close(self):
        self.sock.close()


class RPCStub(TCPClient):
    def __init__(self):
        TCPClient.__init__(self)
        pass

    def AsynHandle(self, d):
        self.send(json.dumps(d).encode('utf-8'))
        # 接受服务器的数据
        leng = self.recv(4)
        length, = struct.unpack('I', leng)
        #print(type(length))
        #print("1")
        data = self.recv(length).decode('utf-8')
        #print("2")
        return data

    def __getattr__(self, function):
        self.find(function)
        def _func(method, *args, **kwargs):
            #  封装调用消息
            d = {'method_name': function, 'method_args': args, 'method_kwargs': kwargs}
            if method == 'Syn':  # 同步处理
                self.send(json.dumps(d).encode('utf-8'))
                leng = self.recv(4)
                length,=struct.unpack('I', leng)
                data = self.recv(length).decode('utf-8')
                return data
            elif method == 'Async':  # 异步处理
                t = MyThread(sock=self.sock, args=d, callback=Print)
                t.start()
            else:
                print("请选择Syn或者Async")
                return
        setattr(self, function, _func)
        return _func


class RPCClient(RPCStub):
    def __init__(self):
        RPCStub.__init__(self)

    def find(self, function):
        self.sock = socket(AF_INET, SOCK_STREAM)
        self.sock.settimeout(4)  # 超时处理，4s连接不上则停止
        self.connect('127.0.0.1', 6000)  # 连接注册中心 127.0.0.1, 6000
        self.send(function.encode())
        data = self.recv(1024).decode()
        self.sock.close()

        self.sock = socket(AF_INET, SOCK_STREAM)
        print(data)
        ip = data[:data.index(' ')]
        port = data[data.index(' ') + 1:]
        port = int(port)

        self.sock.settimeout(3)  # 超时处理，3s连接不上则停止
        while self.connect(ip, port) == 0:
            pass

