import RPC_Registry


if __name__ == '__main__':
    registryCenter = RPC_Registry.RPCRegistry('127.0.0.1')
    print("注册中心建立成功")

#   server用3000端口
#   client用6000端口
    registryCenter.loop(3000, 6000)

