import random
import socket
import sys
import time
from random import choice
import threading
from socket import *
from collections import defaultdict


class RPCRegistry(object):
    def __init__(self, ip):
        self.servers = defaultdict(list)  # 维护的服务列表
        self.ip = ip
        self.connectlist = []  # 与每个服务器维持一个长连接，以发送心跳包的端口列表

    def loop(self, serverPort: int, clientPort: int):
        # 创建服务器套接字，使用IPv4协议，TCP协议
        serverSocket = socket(AF_INET, SOCK_STREAM)
        clientSocket = socket(AF_INET, SOCK_STREAM)
        # 绑定端口号和套接字
        serverSocket.bind((self.ip, serverPort))
        clientSocket.bind((self.ip, clientPort))
        # 开启监听，设置10000个连接缓冲，暂时将连接挂起
        serverSocket.listen(1000)
        clientSocket.listen(10000)
        print('注册中心在', self.ip, '守候在', serverPort, '端口等待服务器调用')
        print('注册中心在', self.ip, '守候在', clientPort, '端口等待客户端调用')
        t1 = threading.Thread(target=self.loop_server, args=(serverSocket,))
        t1.start()
        t2 = threading.Thread(target=self.loop_client, args=(clientSocket,))
        t2.start()

    def heartBeat(self, newServersock, ip, port):
        exceCount = 0
        con_list = []
        while True:
            try:
                conn, addr = newServersock.accept()
                conn.setblocking(False)
                con_list.append(conn)
            except BlockingIOError as b:
                # print(b)
                pass
            for conn in con_list:
                try:
                    # 接受客户端的数据
                    data = conn.recv(1024).decode()
                    if not data:
                        exceCount += 1
                        print("超时一次")
                        if exceCount >= 3:
                            self.delete(ip, port)
                    else:
                        exceCount = 0
                        print(data)
                    time.sleep(2.5)
                except BlockingIOError as e:
                    print(e)
                except ConnectionResetError as c:
                    exceCount += 1
                    print("超时" + str(exceCount) + "次")
                    if exceCount >= 3:
                        print("超时三次，将从注册中心去除服务器" + str(ip) + "," + str(port))
                        self.delete(ip, port)
                        sys.exit()
                    else:
                        time.sleep(2.5)

    def delete(self, ip, port):
        for key in list(self.servers.keys()):
            self.servers[key].remove((ip, port))
            if not self.servers[key]:
                self.servers.pop(key)
        print("剩余的服务器有" + str(self.servers))

    def loop_server(self, serverSocket):
        while True:
            # 等待接受服务器的连接
            conn, addr = serverSocket.accept()
            # print(conn.getsockname())
            try:
                # 接服务器的注册
                data = conn.recv(1024).decode()
                # print(data)
                funcs = data[:data.index('~')]
                ip = data[data.index('~') + 1:data.index(';')]
                port = data[data.index(';') + 1:]

                print("服务器的ip是" + ip + "，端口是" + port + "，注册方法是" + funcs)

                port = int(port)
                while funcs != "":
                    func = funcs[:funcs.index(',')]
                    funcs = funcs[funcs.index(',') + 1:]
                    self.servers[func].append((ip, port))
                print("服务注册成功,可调用的服务器有：")
                print(self.servers)

                # 随机选择一个端口，与服务器建立长连接
                while True:
                    p = random.randint(1, 2999)
                    if p not in self.connectlist:
                        self.connectlist.append(p)
                        break
                    else:
                        pass
                p = str(p)
                conn.send(p.encode())
                # print("******")
                # 连接关闭
                conn.close()

                newServersock = socket(AF_INET, SOCK_STREAM)
                newServersock.bind((self.ip, int(p)))
                newServersock.setblocking(False)
                newServersock.listen(1)

                print("与服务器" + ip + "建立持久连接在端口" + str(p))
                # 创建线程
                t = threading.Thread(target=self.heartBeat, args=(newServersock, ip, port,))
                t.start()

            except Exception as e:
                print(e)
                self.close()

    def loop_client(self, clientSocket):
        while True:
            # 等待接受服务器的连接
            conn, addr = clientSocket.accept()
            # print(conn.getsockname())
            # 这里为了方便，用try-catch来处理服务器自动断开连接
            try:
                # 接受客户端的数据
                func = conn.recv(1024).decode()
                a = self.randomSelect(func)  # 负载均衡算法
                # print(a)
                # print(type(a[0]))
                # print(type(a[1]))
                data = a[0] + ' ' + str(a[1])  # 服务器地址
                print("选择了" + data)
                conn.send(data.encode())
                conn.close()  # 连接关闭
            except Exception as e:
                print(e)
                self.close()

    def randomSelect(self, func):
        list = self.servers.get(func)
        print(list)
        a = choice(list)  # 随机选择一个服务器为它服务
        return a

    def close(self):
        self.servers.clear()
        self.connectlist.clear()
