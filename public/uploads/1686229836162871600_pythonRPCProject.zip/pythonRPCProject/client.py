import time

import RPC_Client

if __name__ == '__main__':
    C = list()
    for i in range(50):
        C.append(RPC_Client.RPCClient())

    for i in range(50):
        result = C[i].add('Async', 2, 2, 5)
        if result is not None:
            print(result)

    time.sleep(3)

    for i in range(50):
        result = C[i].sub('Syn', 5, 1)
        if result is not None:
            print(result)
