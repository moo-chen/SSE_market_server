import threading
import RPC_Server


def add(a, b, c):
    t = a + b + c
    return t


def newServer(ip=str):
    s = RPC_Server.RPCServer(ip, 12000)
    s.register_function(add)  # 服务器注册该方法
    s.publish()  # 向注册中心注册自己并发送心跳包，同时等待客户端建立连接



if __name__ == '__main__':
    '''
    # 启动三台服务器
    t = threading.Thread(target=newServer, args=('127.0.0.2',))
    t.start()
    t2 = threading.Thread(target=newServer, args=('127.0.0.3',))
    t2.start()
    t3 = threading.Thread(target=newServer, args=('127.0.0.4',))
    t3.start()
    '''
    newServer('127.0.0.2')
