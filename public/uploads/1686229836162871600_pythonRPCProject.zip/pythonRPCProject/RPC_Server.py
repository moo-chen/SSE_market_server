import json
import selectors
import struct
import threading
import time
from socket import *


class IOMult_server(object):
    def __init__(self):
        self.poll = selectors.DefaultSelector()

    # 每个的处理逻辑
    def recv_data(self, conn):
        msg = conn.recv(1024)
        if msg:
            data = self.on_msg(msg)
            conn.send(struct.pack('I', len(data)))
            conn.send(data)
        else:
            self.poll.unregister(conn)
            conn.close()

    def acc_conn(self, p_server):
        conn, addr = p_server.accept()
        self.poll.register(conn, selectors.EVENT_READ, self.recv_data)

    def accept_receive_close(self):
        # 注册
        self.poll.register(self.sock, selectors.EVENT_READ, self.acc_conn)
        print('The server is ready to receive')
        # 事件循环
        while True:
            # 事件循环不断地调用select获取被激活的socket
            events = self.poll.select()
            # 遍历event，调用数据处理逻辑
            for e, m in events:
                call_back = e.data
                call_back(e.fileobj)


class RPCStub(object):
    def __init__(self):
        self.data = None

    def from_data(self, data):
        self.data = None
        self.data = json.loads(data.decode('utf-8'))

    def call_method(self, data):
        # 解析数据，调用对应的方法变将该方法执行结果返回
        self.from_data(data)
        method_name = self.data['method_name']
        method_args = self.data['method_args']
        method_kwargs = self.data['method_kwargs']
        tmp = self.funs[method_name](*method_args, **method_kwargs)
        print(tmp)
        r_data = {method_name+"  result": tmp}
        return json.dumps(r_data).encode('utf-8')


class RPCServer(IOMult_server, RPCStub):
    def __init__(self, servername, address):
        IOMult_server.__init__(self)
        RPCStub.__init__(self)
        self.servername = servername
        self.address = address
        self.funs = {}  # 提供可调用的方法
        self.sock = socket(AF_INET, SOCK_STREAM)

    def publish(self):
        self.sock.bind((self.servername, 12001))
        self.sock.settimeout(4)
        while self.sock.connect(('127.0.0.1', 3000)) == 0:
            pass

        func = ""
        for every in self.funs:
            func = func+every+","
        data = func + '~'+self.servername+';'+str(self.address)
        self.sock.sendall(data.encode())

        port = self.sock.recv(4).decode()
        print(port)
        port = int(port)

        # 与注册中心建立持久连接发送心跳包
        sock = socket(AF_INET, SOCK_STREAM)
        sock.settimeout(4)  # 超时处理
        while sock.connect(('127.0.0.1', port)) == 0:
            pass
        print("成功建立持久连接")
        # 创建线程以等待客户端请求
        t = threading.Thread(target=self.loop)
        t.start()
        while True:
            sock.send("heartbeat".encode())
            time.sleep(2)

    def loop(self):
        self.sock = socket(AF_INET, SOCK_STREAM)
        self.sock.bind((self.servername, self.address))
        # 循环监听端口
        self.sock.listen(1000)
        print('Server listen ...')
        self.accept_receive_close()

    def on_msg(self, data):
        return self.call_method(data)

    def register_function(self, function, name=None):
        '''Server端方法注册，Client端只可调用被注册的方法'''
        if name is None:
            name = function.__name__
        self.funs[name] = function
